def printProductName(x):
  print x.getName()

