def calculateTotal(x, y)
  return x.getPrice() + y.getPrice() 
end